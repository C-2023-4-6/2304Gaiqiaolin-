#include<iostream>
using namespace std;

double celsius_to_fah(double cel);
double fahrenheit_to_cels(double fah);